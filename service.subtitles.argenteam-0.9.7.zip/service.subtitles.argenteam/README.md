service.subtitles.argenteam
==========================

argenteam.net subtitle service plugin for XBMC

Roadmap
==============

v1.0

*   Make the sync flag to appear on subtitles that are synced version of the original translation